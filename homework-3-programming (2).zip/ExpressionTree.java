//NEED TO ADD PARENTHESIS FOR INFIX
//VERY IMPORTANT
//DON'T FORGET

import java.util.LinkedList;
import java.util.StringTokenizer;

public class ExpressionTree{
    
    private LinkedList<ExpressionNode> stack;
    private ExpressionNode root;
    private String outputString;
    private boolean validExpression;
    
    public ExpressionTree(String expression){
        
        validExpression = true;
        
        stack = new LinkedList();
        
        StringTokenizer tokenMaker = new StringTokenizer(expression);
        while (tokenMaker.hasMoreTokens()){
            addNode(tokenMaker.nextToken());
        }
        
        if(stack.isEmpty()){
            System.out.println("Invalid input expression: Pop empty stack error");
            validExpression = false;
        }
        else{
            root = stack.pop();
            if(!stack.isEmpty()){
                System.out.println("Invalid input expression: Non-empty stack error");
                validExpression = false;
            }
        }
        
    }
    
    private void addNode(String token){
        ExpressionNode tokenNode = new ExpressionNode(token);
        if(isOperator(token)){
            
            if(stack.isEmpty()){
                System.out.println("Invalid input expression: Pop empty stack error");
                validExpression = false;
            }
            else
                tokenNode.right = stack.pop();
            
            if(stack.isEmpty()){
                System.out.println("Invalid input expression: Pop empty stack error");
                validExpression = false;
            }
            else
                tokenNode.left = stack.pop();
            
            stack.push(tokenNode);
        }
        
        else{
            
            try{
                Integer.parseInt(token);
                stack.push(tokenNode);
            }
            catch(NumberFormatException e){
                System.out.println("Invalid input expression: Invalid token error");
                validExpression = false;
            }
        }
    }
    
    private boolean isOperator(String n){
        if (n.equals("+") || n.equals("-") || n.equals("/") || n.equals("*"))
            return true;
        return false;
    }
    
    public int eval(){
        if (validExpression == false){
            System.out.println("Invalid expression can't be used in methods");
            return -1;
        }
        return eval(root);
    }
    
    private int eval(ExpressionNode t){
        int left = 0;
        int right = 0;
        if(t.data == null)
            return 0;
        if(!isOperator(t.data))
            return Integer.parseInt(t.data);
        if(t.hasLeft())
            left = eval(t.left);
        if(t.hasRight())
            right = eval(t.right);
        return simplify(t, left, right);
    }
    
    private int simplify(ExpressionNode t, int left, int right){
        if(t.data.equals("+"))
            return left+right;
        else if(t.data.equals("-"))
            return left-right;
        else if(t.data.equals("/"))
            return left/right;
        else if(t.data.equals("*"))
            return left*right;
        else
            return Integer.parseInt(t.data);
    }
    
	public String postfix(){
        if (validExpression == false){
            return "Invalid expression can't be used in methods";
        }
        outputString = "";
        postfix(root, outputString);
        return outputString;
    }
    
    private void postfix(ExpressionNode t, String output){
        if(t.hasLeft())
            postfix(t.left, outputString);
        if(t.hasRight())
            postfix(t.right, outputString);
        outputString += t.data+" ";
    }
    
	public String prefix(){
        if (validExpression == false){
            return "Invalid expression can't be used in methods";
        }
        outputString = "";
        prefix(root, outputString);
        return outputString;
    }
    
    private void prefix(ExpressionNode t, String output){
        outputString+=t.data+" ";
        if(t.hasLeft())
            prefix(t.left, outputString);
        if(t.hasRight())
            prefix(t.right, outputString);
    }
    
	public String infix(){
        if (validExpression == false){
            return "Invalid expression can't be used in methods";
        }
        outputString = "";
        infix(root, outputString);
        return outputString;
    }
    
    private void infix(ExpressionNode t, String output){
        if(t.hasLeft())
            infix(t.left, outputString);
        outputString+=t.data+" ";
        if(t.hasRight())
            infix(t.right, outputString);
    }
    
    public static class ExpressionNode{
        
        public ExpressionNode left;
        public ExpressionNode right;
        public String data;
        
        public ExpressionNode(String data){
            this.data = data;
        }
        
        public boolean hasLeft(){
            if(left == null)
                return false;
            return true;
        }
        
        public boolean hasRight(){
            if(right == null)
                return false;
            return true;
        }
        
    }
    
}