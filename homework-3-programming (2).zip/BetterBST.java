import java.lang.Math;

public class BetterBST<T extends Comparable<? super T>> extends BinarySearchTree<T>{
    
	public int height(){
        return height(root);
    }
    
    private int height(BinaryNode<T> t){
        if(t.left == null && t.right == null)
            return 0;
        else if(t.left == null)
            return height(t.right)+1;
        else if(t.right == null)
            return height(t.left)+1;
        else
            return Math.max(height(t.left), height(t.right))+1;
    }
    
	public T imbalance(){ //Doing this pre-order 
        return imbalance(root);
    }
    
    private T imbalance(BinaryNode<T> t){
        if(hasImbalance(t))
            return t.data;
        if(t.left != null)
            return imbalance(t.left);
        if(t.right != null)
            return imbalance(t.right);
        return null;
    }
    
    private boolean hasImbalance(BinaryNode<T> t){
        int left;
        int right;
        if(t.left == null)
            left = -1;
        else
            left = height(t.left);
        
        if(t.right == null)
            right = -1;
        else
            right = height(t.right);
        
        if (left-right>1 || left-right<-1)
            return true;
        return false;
        
    }
    
	public T smallestGreaterThan(T t){
        return smallestGreaterThan(root, t);
    }
    
    private T smallestGreaterThan(BinaryNode<T> root, T t){
        if(root == null)
            return null;
        else if(root.data.compareTo(t)<=0 && root.right == null)
            return null;
        else if(root.data.compareTo(t)<=0)
            return smallestGreaterThan(root.right, t);
        else if(root.left != null){
            if (root.left.data.compareTo(t)>0)
                return smallestGreaterThan(root.left, t);
        }
        return root.data;
    }
    
    /*
    private BinaryNode<T> goLessThan(BinaryNode<T> root, T t){
        if(root.left != null && root.data.compareTo(t)>0){
            return goLessThan(root.left, t);
        }
        return root;
    }
    
    private BinaryNode<T> goGreaterThan(BinaryNode<T> root, T t){
        if(root.right != null && root.data.compareTo(t)<=0){
            return goGreaterThan(root.right, t);
        }
        return root;
    }
    */
    
    public BinarySearchTree<T> mirror(){
        if (root == null){
            BetterBST emptyTree = new BetterBST();
            return emptyTree;
        } 
        BinaryNode newRoot = root;
        return mirror(newRoot);
    }

    private BinarySearchTree<T> mirror(BinaryNode<T> root){ //Modified version of code from midterm
        if(root.left == null && root.right == null){
            BetterBST<T> rootTree = new BetterBST();
            rootTree.root = root;
            return rootTree;
        }
        BinaryNode temp = root.left; 
        root.left = root.right; 
        root.right = temp;
        if(root.left != null)
            mirror(root.left); 
        if(root.right != null)
            mirror(root.right);
        BetterBST<T> rootTree = new BetterBST();
        rootTree.root = root;
        return rootTree;
    }
    
	public void prettyPrint(){
        String currentLine = "";
        
        int height = height()+1;
        int width = (int) Math.pow(2, height);
        String[] lineArray = new String[height];
        
        for(int i=0; i<height; i++){
                lineArray[i]="";
            }
        
        lineArray = addTree(root, 0, lineArray);
        
        for(int i=0; i<height; i++){
                System.out.println(lineArray[i]);
            }

    }
    
    private String[] addTree(BinaryNode<T> t, int yCount, String[] array){
        array[yCount] += t.data.toString();
        System.out.println(array[yCount]);
        if (t.left != null)
            array = addTree(t.left, yCount+1, array);
        if (t.right != null)
            for(int i=0; i<array.length; i++){
                array[i] += "    ";
            }
            array = addTree(t.right, yCount+1, array);
        return array;
    }
    
}
