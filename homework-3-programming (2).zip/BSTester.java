public class BSTester{
    
    public static void main(String[] args){
        BetterBST tester = new BetterBST();
        tester.insert(1);
        tester.insert(2);
        tester.insert(4);
        
        tester.prettyPrint();
        System.out.println();
        //tester.mirror().prettyPrint();
        System.out.println(tester.smallestGreaterThan(3));
        System.out.println(tester.smallestGreaterThan(1));
        System.out.println(tester.imbalance());
        System.out.println(tester.height());
        System.out.println();
        
        BetterBST tester2 = new BetterBST();
        tester2.insert(2);
        tester2.insert(1);
        tester2.insert(4);
        
        //tester2.prettyPrint();
        //tester2.mirror().prettyPrint();
        System.out.println(tester2.smallestGreaterThan(3));
        System.out.println(tester2.smallestGreaterThan(1));
        System.out.println(tester2.imbalance());
        System.out.println(tester2.height());
        System.out.println();
        
    }
    
}