public interface ExpressionTreeInterface
{
	public int eval();
	public String postfix();
	public String prefix();
	public String infix();
}
