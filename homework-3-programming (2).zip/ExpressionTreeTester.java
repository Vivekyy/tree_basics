public class ExpressionTreeTester{
    
    public static void main(String[] args){
        
        ExpressionTree tester1 = new ExpressionTree("1 1 +");
        System.out.println(tester1.postfix());
        System.out.println(tester1.prefix());
        System.out.println(tester1.infix());
        System.out.println(tester1.eval());
        System.out.println();
        
        
        ExpressionTree tester2 = new ExpressionTree("2 5 + 7 4 2 - - *");
        System.out.println(tester2.postfix());
        System.out.println(tester2.prefix());
        System.out.println(tester2.infix());
        System.out.println(tester2.eval());
        System.out.println();
        
        ExpressionTree tester3 = new ExpressionTree("11 12 +");
        System.out.println(tester3.postfix());
        System.out.println(tester3.prefix());
        System.out.println(tester3.infix());
        System.out.println(tester3.eval());
        System.out.println();
        
        
        ExpressionTree tester4 = new ExpressionTree("f 1 +");
        System.out.println(tester4.postfix());
        System.out.println(tester4.prefix());
        System.out.println(tester4.infix());
        System.out.println(tester4.eval());
        System.out.println();
        
        
    }
    
}